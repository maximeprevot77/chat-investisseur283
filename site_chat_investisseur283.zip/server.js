const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");
const fs = require("fs");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "CHANGE_ME";

const dataDir = path.join(__dirname, "data");
const dataFile = path.join(dataDir, "messages.json");
fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, "[]");

function readMessages() {
  try { return JSON.parse(fs.readFileSync(dataFile, "utf8")); }
  catch { return []; }
}
function saveMessages(messages) {
  fs.writeFileSync(dataFile, JSON.stringify(messages.slice(-1000), null, 2));
}

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/admin/login", (req, res) => {
  const ok = req.body?.password === ADMIN_PASSWORD;
  res.json({ ok });
});

app.get("/api/messages", (req, res) => {
  res.json(readMessages());
});

io.on("connection", socket => {
  socket.on("join", ({ name }) => {
    socket.data.name = String(name || "Visiteur").slice(0, 60);
  });

  socket.on("message", text => {
    const clean = String(text || "").trim().slice(0, 1000);
    if (!clean) return;

    const msg = {
      id: Date.now() + Math.random(),
      name: socket.data.name || "Visiteur",
      text: clean,
      sender: "visitor",
      time: new Date().toISOString()
    };
    const messages = readMessages();
    messages.push(msg);
    saveMessages(messages);
    io.emit("message", msg);
  });

  socket.on("admin_message", ({ password, text }) => {
    if (password !== ADMIN_PASSWORD) return;
    const clean = String(text || "").trim().slice(0, 1000);
    if (!clean) return;

    const msg = {
      id: Date.now() + Math.random(),
      name: "Moi",
      text: clean,
      sender: "admin",
      time: new Date().toISOString()
    };
    const messages = readMessages();
    messages.push(msg);
    saveMessages(messages);
    io.emit("message", msg);
  });
});

server.listen(PORT, () => {
  console.log(`Chat lancé sur http://localhost:${PORT}`);
});