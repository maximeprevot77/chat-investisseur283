# Site de chat — investisseur283

## Ce qui est inclus
- `public/index.html` : page publique de discussion
- `public/admin.html` : interface pour répondre
- `server.js` : serveur Express + Socket.IO
- `data/messages.json` : stockage local des messages
- `package.json` : dépendances

## Lancer le site
1. Installer Node.js.
2. Dans ce dossier : `npm install`
3. Définir la variable `ADMIN_PASSWORD` avec un mot de passe personnel.
4. Lancer : `npm start`
5. Ouvrir `http://localhost:3000/`
6. Pour l'administration : `http://localhost:3000/admin.html`

Pour un vrai déploiement public, il faut héberger ce projet sur un serveur Node.js et définir `ADMIN_PASSWORD` côté serveur. Ne laisse pas le mot de passe par défaut `CHANGE_ME`.
